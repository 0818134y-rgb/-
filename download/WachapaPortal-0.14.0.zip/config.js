/* ゲーム投稿サイト用（広告なし） */
window.PG_CONFIG = {"portal": true, "adTags": {}};
