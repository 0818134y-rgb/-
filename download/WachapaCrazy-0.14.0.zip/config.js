/* CrazyGames 用（広告なし・CrazyGames SDK） */
window.PG_CONFIG = {"portal": true, "crazy": true, "adTags": {}};
