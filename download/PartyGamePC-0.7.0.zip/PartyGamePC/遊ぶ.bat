@echo off
rem �p�[�e�B�[�Q�[�� PC �ł��A�A�v���̂悤�ȃE�B���h�E�ŊJ���܂�
setlocal
cd /d "%~dp0"
set "URL="
if exist "site.txt" set /p URL=<"site.txt"
if not defined URL set "URL=file:///%~dp0game/index.html"
set "URL=%URL:\=/%"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="%URL%" --window-size=1280,880
  exit /b 0
)
if exist "%CHROME%" (
  start "" "%CHROME%" --app="%URL%" --window-size=1280,880
  exit /b 0
)
start "" "%URL%"
exit /b 0
